<!DOCTYPE html>

<head>
<title>Frame Details</title>
</head>
<frameset rows="15%,*" >
<frame src="head.php" scrolling=no >
<frameset cols="30%,*" noresize="noresize" scrolling=no>
<frame src="bar.php">
<frame name="Frame2" src="intro.php">
</frameset>
<frameset>

</html>
