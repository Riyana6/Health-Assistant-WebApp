<!DOCTYPE html>
<head></head>
<body>
<style>

h2.a{
background-color:powderblue
}

			
</style>

<h2 class="a" style="color:red;font-size:50px" align="center" bgcolor="yellow" >WELCOME</h2>
<hr>
<p bgcolor="red"><b>Small Description</b></p>
<textarea cols="140" rows="20" width="30%" style="background-color:#e6ffe6;opacity:0.8"></textarea>
<hr>
  
</body>
</html>