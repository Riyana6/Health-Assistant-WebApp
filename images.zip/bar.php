<html>

<head>
    <title>Menu</title>
</head>
<style>
button {
    background-color: orange;
    width: 90%;
    padding: 40px;
    margin: 20px;
}

a {
    text-decoration: none;
    font-size: 20px
}

a:hover {
    color: red;
}
</style>

<body style="font-size:30px">
    <button><a href="intro.php" target="Frame2">Introduction</a></button>
    <button><a href="Vpatientdetails.php" target="Frame2">Patient Profile</a></button>
    <button><a href="login.php" target="Frame2">Doctor Login</a></button>
    <button><a href="register.php" target="Frame2">Register</a></button>

</body>

</html>