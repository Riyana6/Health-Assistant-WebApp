<html>

<head>
    <title>My</title>
    <style>
    body {
        background-color: yellow;
        font-size: large
    }

    div {
        position: absolute;
        left: 20%;
        top: 4px;
        margin: 10px;
        font-size: 70px
    }
    </style>
</head>

<body>

    <div>
        <b>YOUR HEALTH ASSISTANT</b>
    </div>
</body>

</html>